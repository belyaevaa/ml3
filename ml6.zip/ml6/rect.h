#ifndef RECT_H
#define RECT_H

class QPainter;

class Rect
{
public:
    Rect();
    Rect(int x1, int y1, int x2, int y2);

    void draw(QPainter *painter, int n);
    bool contains(int x, int y);
    Rect intersection(const Rect & r);
    int getWidth() {return x2-x1;}
private:
    int x1,y1,x2,y2;
};

#endif // RECT_H
